#!/usr/bin/env bash
set -euo pipefail
repo=$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)
sim=${MODELSIM_BIN:-/mnt/ds1515/opt/intelFPGA/17.0/modelsim_ase/bin}
out=$(mktemp -d "$repo/build/dco-page-contract.XXXXXX")
cd "$out"
sources=( "$repo/scripts/experiment/tb_dco_page_contract.sv" \
  "$repo/quartus/si5340a_controller_dco.v" \
  "$repo/quartus/i2c_bus_controller_dco.v" \
  "$repo/quartus/si5340a_i2c_reg_controller_dco.v" \
  "$repo/quartus/si5340_controller/initial_config.v" \
  "$repo/quartus/si5340_controller/clock_divider.v" \
  "$repo/quartus/si5340_controller/edge_detector.v" \
  "$repo/quartus/si5340_controller/si5340a_clk_frq_sel_gen.v" \
  "$repo/quartus/si5340_controller/si5340a_freq_prameter_selector.v" )
if [[ -n ${IVERILOG_ROOT:-} ]]; then
  "$IVERILOG_ROOT/usr/bin/iverilog" -B "$IVERILOG_ROOT/usr/lib/x86_64-linux-gnu/ivl" \
    -g2012 -s tb_dco_page_contract -o test.vvp "${sources[@]}"
  "$IVERILOG_ROOT/usr/bin/vvp" -M "$IVERILOG_ROOT/usr/lib/x86_64-linux-gnu/ivl" test.vvp "$@"
  exit
fi
"$sim/vlib" work
"$sim/vlog" -sv "${sources[@]}"
"$sim/vsim" -c -voptargs=+acc work.tb_dco_page_contract "$@" \
  -do 'onbreak {quit -code 1}; onerror {quit -code 1}; run -all; quit -code 0'
