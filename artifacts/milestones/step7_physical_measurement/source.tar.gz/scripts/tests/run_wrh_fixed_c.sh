#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)
TEST_OUT=$(mktemp -d)
trap 'rm -f "$TEST_OUT/fixed_test"; rmdir "$TEST_OUT"' EXIT
${CC:-cc} -std=gnu99 -DWRH_FIXED_SETP_DIAGNOSTIC=1 -Wall -Wextra -Wno-unused-parameter -Wno-unused-variable \
  -fsanitize=undefined -fno-sanitize-recover=all \
  -I "$ROOT/scripts/tests/wrh_strict" \
  "$ROOT/scripts/tests/wrh_strict/fixed_test.c" -o "$TEST_OUT/fixed_test"
"$TEST_OUT/fixed_test"
